/**
 * 
 */
/**
 * 
 */
module structureLineaire {
}